import { identifierModuleUrl } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-progress',
  templateUrl: './progress.component.html',
  styleUrls: ['./progress.component.css']
})


export class ProgressComponent implements OnInit {

  stepTraversal: { stepNo: number, stepDescription: string, stepState: string }[] = [

    { "stepNo": 1, "stepDescription": "Reporting Information", "stepState": "Active" },
    { "stepNo": 2, "stepDescription": "Insured Driver", "stepState": "Inactive" },
    { "stepNo": 3, "stepDescription": "Losses & Damage", "stepState": "Inactive" },
    { "stepNo": 4, "stepDescription": "Injuries & Witnesses", "stepState": "Inactive" },
    { "stepNo": 5, "stepDescription": "Review & submit", "stepState": "Inactive" },

  ];

  previousBtn = document.getElementById('previousBtn');
  nextBtn = document.getElementById('nextBtn');
  finishBtn = document.getElementById('finishBtn');
  content = document.getElementById('content');
  bullets = [...document.querySelectorAll('.bullet')];
  MAX_STEPS = 4;
  currentStep = 1;
  previousStep;
  currentState = "Inactive";

  constructor() { }

  nxtBtn() {

    if (this.currentStep != this.MAX_STEPS) {

      let currentState = this.stepTraversal[this.currentStep].stepState;

      if (currentState == "Inactive") {
        this.stepTraversal[this.currentStep].stepState = "Active"
        const target = document.getElementsByClassName('bullet')[this.currentStep].classList.add('completed');
        const text = document.getElementsByClassName('step-text')[this.currentStep].classList.add('active');
        const target1 = document.getElementsByClassName('bullet')[this.currentStep - 1].classList.add('previous');
        const text1 = document.getElementsByClassName('step-text')[this.currentStep - 1].classList.add('previous');
      }
      else if (this.currentState == "Active") {
        this.stepTraversal[this.currentStep].stepState = "Done"
      }

      this.currentStep++;
    }
    


  }


  prevBtn() {
    let currentState = this.stepTraversal[this.currentStep - 1].stepState;
    console.log(this.stepTraversal[this.currentStep - 1].stepDescription + ' ' + this.currentStep);
    console.log(currentState);

    if (this.currentStep != 1) {
      if (currentState == "Active") {
        this.stepTraversal[this.currentStep - 1].stepState = "Inactive";

        const target1 = document.getElementsByClassName('completed')[this.currentStep - 2].classList.remove("previous")
        // const target2 = document.getElementsByClassName('completed')[this.currentStep - 1].classList.remove("completed")

        const text1 = document.getElementsByClassName('active')[this.currentStep - 2].classList.remove("previous")
        // const text2 = document .getElementsByClassName('active')[this.currentStep - 1].classList.remove("active")

      }
      this.currentStep--;
    }

  }


  submit(){
      //Submit your form and go to some other component
  }

  ngOnInit(): void {

  }
}